package com.servlet.demo;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MethodDemo")
public class MethodDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
   @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
	     String username=request.getParameter("username");
	     response.getWriter().println("Hello World from get method!" +username);
	   
	}
   @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
	     String username=request.getParameter("username");
	     response.getWriter().println("Hello World from post method!" +username);
	   
	}
   @Override
   protected void doPut(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
	     String username=request.getParameter("username");
	     response.getWriter().println("Hello World from put method!" +username);
	   
	}
   @Override
   protected void doDelete(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
	     String username=request.getParameter("username");
	     response.getWriter().println("Hello World from delete method!" +username);
	   
	}
   
    
  

}
