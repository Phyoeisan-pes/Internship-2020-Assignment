package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.University;
import com.example.demo.repository.UniversityRepository;

@Service
public class UniversityService {
	
	@Autowired
	UniversityRepository universityRepository;
	
	public List<University> getUniversity(){
		return universityRepository.findAll();
	}
	
	public University addUniversity(University university) {
		return universityRepository.save(university);
	}
	
	public University getUniversityById(int id) {
		return universityRepository.findById(id).orElse(null);
	}
	
	public void deleteUniversity(int id) {
		universityRepository.deleteById(id);
	}

	
}
