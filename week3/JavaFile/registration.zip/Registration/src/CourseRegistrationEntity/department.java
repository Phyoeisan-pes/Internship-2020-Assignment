package CourseRegistrationEntity;


import java.util.*;

/**
 * 
 */
public class department {

    /**
     * Default constructor
     */
    public department() {
    }


}