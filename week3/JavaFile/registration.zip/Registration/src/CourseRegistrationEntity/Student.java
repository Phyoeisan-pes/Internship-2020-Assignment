package CourseRegistrationEntity;

public class Student {

	int stu_id;
	String stu_name;
	String stu_phone;
	String stu_adddress;
	String stu_email;
	
	void register() {
		
	}
	
public class registered_stu extends Student{
	 void login() {
		 
	 }
}

public class login_stu extends Student{
	void submit() {
		
	}
}

public class registration_Form{
	   
}

public class course extends registration_Form{
	int course_id;
	String name;
	
	public class department extends course{
		
	}
}

public class semesters extends registration_Form{
	
}

public class adminstrator {
	
	void access_course_registration() {
		
	}
	void view() {
		
	}
	void confirm() {
		 
	}
}
	
	
	}
