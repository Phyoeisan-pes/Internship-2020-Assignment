package CourseRegistrationEntity;


import java.util.*;

/**
 * 
 */
public class login_stu extends Students {

    /**
     * Default constructor
     */
    public login_stu() {
    }


    /**
     * 
     */
    public void can_submit() {
        // TODO implement here
    }

}