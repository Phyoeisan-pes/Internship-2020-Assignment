package CourseRegistrationEntity;


import java.util.*;

/**
 * 
 */
public class registration_form {

    /**
     * Default constructor
     */
    public registration_form() {
    }





}