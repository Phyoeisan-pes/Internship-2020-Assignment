package CourseRegistrationEntity;


import java.util.*;

/**
 * 
 */
public class course {

    /**
     * Default constructor
     */
    public course() {
    }

    /**
     * 
     */
    public int id;

    /**
     * 
     */
    public String name;



}