package CourseRegistrationEntity;


import java.util.*;

/**
 * 
 */
public class registered_stu extends Students {

    /**
     * Default constructor
     */
    public registered_stu() {
    }

    /**
     * 
     */
    public void can_login() {
        // TODO implement here
    }

}