package CourseRegistrationEntity;


import java.util.*;


public class adminstrator {

   
    public adminstrator() {
    }





}