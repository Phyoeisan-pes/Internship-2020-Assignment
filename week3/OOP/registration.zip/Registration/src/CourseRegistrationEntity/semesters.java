package CourseRegistrationEntity;


import java.util.*;

/**
 * 
 */
public class semesters {

    /**
     * Default constructor
     */
    public semesters() {
    }


}