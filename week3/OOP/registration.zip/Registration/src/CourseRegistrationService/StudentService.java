package CourseRegistrationService;

import CourseRegistrationEntity.Students;

public class StudentService {

	 public void can_register(Students stu) {
	        
	    }
}
