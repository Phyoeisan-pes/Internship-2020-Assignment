package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Project;
@Repository
public interface ProjectRepository extends JpaRepository<Project, Long>{
	
	 List<Project> findByIdIn(List<Long> idList);
	   /* @Query (value = "Select p from Project  p where p.id in ?1")
	    List<Project> findByIdInWithQuery(List<Long> idList);
	    @Query (value = "select * from project where id in ?1",nativeQuery = true)
	    List<Project> findByIdInWithNativeQuery(List<Long> idList);*/

	

}
