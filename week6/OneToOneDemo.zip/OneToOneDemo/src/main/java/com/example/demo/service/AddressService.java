package com.example.demo.service;

import java.util.Collection;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Address;

import com.example.demo.repository.AddressRepository;

@Service
public class AddressService {
	@Autowired
	AddressRepository addressRepository;
	
	public Address save(Address address){
	       return addressRepository.save(address);
	    }


	    public List<Address> findAll(){
	        return addressRepository.findAll();
	    }




		public Collection<Address> saveAll(Collection<Address> address1) {
			// TODO Auto-generated method stub
			return null;
		}


	




		

		
	

}
