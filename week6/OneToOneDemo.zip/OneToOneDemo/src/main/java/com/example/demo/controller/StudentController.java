package com.example.demo.controller;


import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Address;


import com.example.demo.entity.Student;
import com.example.demo.service.AddressService;
import com.example.demo.service.StudentService;


@RestController
public class StudentController {
	@Autowired
	StudentService studentService;
	
	@Autowired
	AddressService addressService;
    
	 @PostMapping (value = "/students")
	    public Student createStudent(@RequestBody Student student){

	    	Collection<Address> address= student.getAddress();
	        if(address !=null){
	        	address = addressService.saveAll(address);
	        }

	       

	       return studentService.save(student);
	    }
	 
	 @GetMapping (value = "/students")
	    public List<Student> findAll(){
	        return studentService.findAll();
	    }
	 
	
	 
}
